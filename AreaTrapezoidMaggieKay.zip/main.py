
# Area of a trapezoid
# This program will ask the user for the dimensions of a trapezoid 
# It will then calculate the area.
print ('Today we will calculate the area of a trapezoid.')

# get the base1 from the user and convert it to an integer
base1 = float(input('What is the bottom base of the trapezoid? (cm) '))

# get the base2 from the user and convert it to an integer
base2 = float(input('What is the top base of the trapezoid? (cm)'))

# get the height from the user and convert it to an integer
height = float(input('What is the height of the trapezoid? (cm)'))

# calculate the area of the trapezoid
area = ((base1 + base2)/ 2) * height

# display the area
print ("The area of the trapezoid with bottom base of " + str(base1) + 
"cm and top base of " + str(base2) + "cm and height of " + str(height) + "cm is " + str(area) + "cm^2")